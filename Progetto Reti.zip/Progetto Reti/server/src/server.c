#if defined WIN32
#include <winsock.h>
#else
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif
#include <stdio.h>
#include <time.h>
#include "protocol.h"

#define NO_ERROR 0
void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

// Generation functions
void generate_numeric(char *password, int length) {
    for (int i = 0; i < length; i++) {
        password[i] = '0' + rand() % 10;
    }
    password[length] = '\0';
}

void generate_alpha(char *password, int length) {
    for (int i = 0; i < length; i++) {
        password[i] = 'a' + rand() % 26;
    }
    password[length] = '\0';
}

void generate_mixed(char *password, int length) {
    for (int i = 0; i < length; i++) {
        if (rand() % 2)
            password[i] = 'a' + rand() % 26;
        else
            password[i] = '0' + rand() % 10;
    }
    password[length] = '\0';
}

void generate_secure(char *password, int length) {
    const char *chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()";
    int n = strlen(chars);
    for (int i = 0; i < length; i++) {
        password[i] = chars[rand() % n];
    }
    password[length] = '\0';
}

int main() {
    #if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}

    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    char buffer[128], password[33]; // Buffer for received data and password
    int length;

    srand(time(NULL)); // Initialize the random number generator

    // Create the socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(DEFAULT_PORT);

    // Bind the socket to the address and port
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        closesocket(server_fd);
        exit(EXIT_FAILURE);
    }

    // Start listening for connections
    if (listen(server_fd, QLEN) < 0) {
        perror("Listen failed");
        closesocket(server_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", DEFAULT_PORT);

    while (1) {
        // Accept a new connection
        if ((client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_addr_len)) < 0) {
            perror("Accept failed");
            continue;
        }

        // Print connection information
        printf("New connection from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        while (1) {
            // Receives the command from the client
            memset(buffer, 0, sizeof(buffer));
            if (recv(client_fd, buffer, sizeof(buffer) - 1, 0) <= 0) {
                printf("Client disconnected\n");
                break;
            }

            // Command parsing
            char type = buffer[0];
            length = atoi(buffer + 2);

            // Check the valid length
            if (length < MIN_LENGTH || length > MAX_LENGTH) {
                const char *error = "Error: Invalid length\n";
                send(client_fd, error, strlen(error), 0);
                continue;
            }

            // Generate password based on the required type
            switch (type) {
                case 'n':
                    generate_numeric(password, length);
                    break;
                case 'a':
                    generate_alpha(password, length);
                    break;
                case 'm':
                    generate_mixed(password, length);
                    break;
                case 's':
                    generate_secure(password, length);
                    break;
                default:
                    send(client_fd, "Error: Invalid type\n", 21, 0);
                    continue;
            }

            // Send the generated password to the client
            send(client_fd, password, strlen(password), 0);
        }

        closesocket(client_fd);
    }

    closesocket(server_fd);
    clearwinsock();
    return 0;
}
