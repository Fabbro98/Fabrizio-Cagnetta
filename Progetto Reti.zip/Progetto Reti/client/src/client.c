#if defined WIN32
#include <winsock.h>
#else
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif
#include <stdio.h>
#include "protocol.h"

#define NO_ERROR 0
void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

int main() {
    #if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}

    int client_fd;
    struct sockaddr_in server_addr;
    char buffer[128], response[128];

    // Create the socket
    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(DEFAULT_PORT);
    inet_pton(AF_INET, DEFAULT_IP, &server_addr.sin_addr);

    // Connection to the server
    if (connect(client_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        closesocket(client_fd);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server at %s:%d\n", DEFAULT_IP, DEFAULT_PORT);

    while (1) {
        printf("Enter command (n/a/m/s length or q to quit): ");
        fgets(buffer, sizeof(buffer), stdin);

        // Removes newline
        buffer[strcspn(buffer, "\n")] = '\0';

        // Check the exit command
        if (buffer[0] == 'q') {
            printf("Closing connection...\n");
            break;
        }

        // Send command to server
        send(client_fd, buffer, strlen(buffer), 0);

        // He receives the answer
        memset(response, 0, sizeof(response));
        if (recv(client_fd, response, sizeof(response) - 1, 0) <= 0) {
            printf("Server disconnected\n");
            break;
        }

        printf("Password: %s\n", response);
    }

    closesocket(client_fd);
    clearwinsock();
    return 0;
}
