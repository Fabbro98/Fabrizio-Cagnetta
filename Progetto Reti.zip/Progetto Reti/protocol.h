#ifndef PROTOCOL_H
#define PROTOCOL_H

#define DEFAULT_PORT 8080
#define DEFAULT_IP "127.0.0.1"
#define QLEN 5          // Maximum length of pending connection queue
#define MIN_LENGTH 6    // Minimum password length
#define MAX_LENGTH 32   // Maximum password length

// Password Generation Functions
void generate_numeric(char *password, int length);
void generate_alpha(char *password, int length);
void generate_mixed(char *password, int length);
void generate_secure(char *password, int length);

#endif // PROTOCOL_H

